// Extracted from original single-file prototype.
// ═══ Navigation ═══
function showScreen(id) {
  document.querySelectorAll('.screen,.capture-screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById('screen-' + id);
  if (el) el.classList.add('active');
  window.scrollTo(0,0);
}
function goHome() { showScreen('home'); }

// ═══ Capture ═══
let alignTimer, captureState = 'searching';

function goToCapture() {
  showScreen('capture');
  resetCapture();
  // Simulate document detection after 1.5s
  setTimeout(() => {
    if (captureState !== 'processing') alignDoc();
  }, 1500);
}

function alignDoc() {
  captureState = 'aligned';
  document.getElementById('doc-mock').classList.add('aligned');
  ['c-tl','c-tr','c-bl','c-br'].forEach(id => {
    const c = document.getElementById(id);
    c.classList.remove('gold'); c.classList.add('green');
  });
  document.getElementById('vf-status').textContent = 'Document detected ✓';
  document.getElementById('vf-status').className = 'status-label status-aligned';
}

function resetCapture() {
  captureState = 'searching';
  clearTimeout(alignTimer);
  document.getElementById('doc-mock').classList.remove('aligned','processing');
  ['c-tl','c-tr','c-bl','c-br'].forEach(id => {
    const c = document.getElementById(id); c.classList.remove('green'); c.classList.add('gold');
  });
  document.getElementById('vf-status').textContent = 'Searching for document…';
  document.getElementById('vf-status').className = 'status-label status-searching';
  document.getElementById('processing-overlay').classList.remove('active');
  document.getElementById('captured-overlay').classList.remove('active');
  document.getElementById('capture-controls').style.display = 'flex';
  document.getElementById('blurry-error').classList.remove('active');
  document.getElementById('capture-greeting').style.opacity = '1';
}

function startCapture() {
  // 20% chance of blurry error for demo realism
  if (Math.random() < 0.2 && captureState !== 'aligned') {
    document.getElementById('capture-controls').style.display = 'none';
    document.getElementById('blurry-error').classList.add('active');
    return;
  }
  captureState = 'processing';
  document.getElementById('capture-controls').style.display = 'none';
  document.getElementById('capture-greeting').style.opacity = '0';
  document.getElementById('doc-mock').classList.add('processing');
  document.getElementById('processing-overlay').classList.add('active');
  const steps = ['Extracting customer info…','Reading VIN…','Looking up vehicle (NHTSA)…','OCR complete — 96% confidence'];
  let i = 0;
  const interval = setInterval(() => {
    if (i < steps.length) document.getElementById('proc-sub').textContent = steps[i++];
    else clearInterval(interval);
  }, 500);
  setTimeout(() => {
    document.getElementById('processing-overlay').classList.remove('active');
    document.getElementById('captured-overlay').classList.add('active');
  }, 2200);
  setTimeout(() => showScreen('verify'), 3000);
}

// ═══ Language toggle ═══
function setLang(lang) {
  document.getElementById('lang-en').classList.toggle('active', lang === 'en');
  document.getElementById('lang-es').classList.toggle('active', lang === 'es');
}

// ═══ Contact preference toggle ═══
function setContact(pref) {
  document.getElementById('contact-call').classList.toggle('active', pref === 'call');
  document.getElementById('contact-text').classList.toggle('active', pref === 'text');
}

// ═══ Owned toggle ═══
let isOwned = false;
function toggleOwned() {
  isOwned = !isOwned;
  const btn = document.getElementById('owned-toggle');
  const fields = document.getElementById('lienholder-fields');
  const msg = document.getElementById('owned-msg');
  btn.textContent = isOwned ? 'Has Lienholder' : 'Mark as Owned';
  btn.classList.toggle('active', isOwned);
  fields.style.display = isOwned ? 'none' : 'block';
  msg.style.display = isOwned ? 'block' : 'none';
}

// ═══ Tracker ═══
const stagesData = [
  {num:1, label:'Received',    icon:'doc',      message:"Stay Blessed got your info — Sara's team is on it."},
  {num:2, label:'Calling',     icon:'phone',    message:'Sara is calling Maria now'},
  {num:3, label:'Quoting',     icon:'sparkles', message:'Quoting with our markets · ~3 min'},
  {num:4, label:'Quote Ready', icon:'send',     message:'Quote ready — Sara is texting Maria now'},
  {num:5, label:'Bound',       icon:'check',    message:'Coverage active · Welcome packet sent'}
];
const iconSvg = {
  doc:'<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"/></svg>',
  phone:'<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.105a2.25 2.25 0 00-2.326.94l-.879 1.32a.75.75 0 01-1.034.214 14.293 14.293 0 01-5.97-5.97.75.75 0 01.214-1.034l1.32-.879a2.25 2.25 0 00.94-2.326L7.385 4.5A1.125 1.125 0 006.294 3.75H4.875A2.25 2.25 0 002.25 6v.75z"/></svg>',
  sparkles:'<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.847.813a4.5 4.5 0 00-3.09 3.091z"/></svg>',
  send:'<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 12L3.269 3.125A59.769 59.769 0 0121.485 12 59.768 59.768 0 013.27 20.875L5.999 12zm0 0h7.5"/></svg>',
  check:'<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>'
};
let currentStage = 3, stageInterval = null;

function goToTracker(start) {
  showScreen('tracker');
  currentStage = start;
  renderStages();
  if (stageInterval) clearInterval(stageInterval);
  if (currentStage < 5) {
    stageInterval = setInterval(() => {
      currentStage++;
      renderStages();
      if (currentStage >= 5) clearInterval(stageInterval);
    }, 4000);
  }
}

function submitToTracker() { goToTracker(1); }

function renderStages() {
  const repCard = document.getElementById('rep-card');
  repCard.style.display = currentStage >= 2 ? 'flex' : 'none';
  if (currentStage === 5) {
    document.getElementById('rep-active').style.display = 'none';
    document.getElementById('bound-celebration').classList.add('active');
  } else {
    document.getElementById('rep-active').style.display = 'flex';
    document.getElementById('bound-celebration').classList.remove('active');
  }
  const list = document.getElementById('stages-list');
  list.innerHTML = '';
  stagesData.forEach((stage, i) => {
    const isActive = stage.num === currentStage;
    const isComplete = stage.num < currentStage;
    const isFuture = stage.num > currentStage;
    const row = document.createElement('div');
    row.className = 'stage-row slide-up';
    row.style.animationDelay = (i * 0.05) + 's';
    const connBg = stage.num < currentStage ? 'linear-gradient(180deg,#C9A961,rgba(201,169,97,0.2))' : 'rgba(255,255,255,0.08)';
    const iconClass = isActive ? 'active' : isComplete ? 'complete' : 'future';
    const titleColor = isActive ? 'white' : isComplete ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.3)';
    const msgColor = isActive ? 'rgba(255,255,255,0.7)' : isComplete ? 'rgba(255,255,255,0.5)' : 'rgba(255,255,255,0.25)';
    row.innerHTML = `
      ${i < stagesData.length-1 ? `<div class="stage-connector" style="background:${connBg}"></div>` : ''}
      <div class="stage-icon-wrap">
        <div class="stage-icon ${iconClass}">${iconSvg[stage.icon]}</div>
        ${isActive ? '<div class="stage-pulse"></div>' : ''}
      </div>
      <div class="stage-content">
        <div class="stage-title-row">
          <h3 class="stage-title" style="color:${titleColor}">${stage.label}</h3>
          ${isActive && currentStage < 5 ? `<div class="stage-now-pill"><div class="stage-now-dot"></div><span class="stage-now-text">Now</span></div>` : ''}
          ${stage.num === 5 && isActive ? '<span>🎉</span>' : ''}
        </div>
        <p class="stage-msg" style="color:${msgColor}">${isFuture ? '…' : stage.message}</p>
        ${isComplete ? `<div class="stage-time">${i+2}m ago</div>` : ''}
      </div>`;
    list.appendChild(row);
  });
}

function toggleCustomerView() {
  const banner = document.getElementById('customer-banner');
  const btn = document.getElementById('customer-toggle');
  banner.classList.toggle('active');
  btn.textContent = banner.classList.contains('active') ? 'Internal View' : 'Show Customer';
}

// ═══ Telegram ═══
let tgClaimed = false;

function tgScenario(type, el) {
  document.querySelectorAll('.tg-demo-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  tgClaimed = false;
  const badge = document.getElementById('tg-lang-badge');
  const claimBtn = document.getElementById('tg-claim-btn');
  const claimedMsg = document.getElementById('tg-claimed-msg');
  const systemMsg = document.getElementById('tg-system-msg');
  claimedMsg.classList.remove('visible');
  systemMsg.classList.remove('visible');
  claimBtn.className = 'tg-btn claim-btn';
  claimBtn.textContent = '✋ I\'m on it';
  claimBtn.onclick = tgClaim;
  if (type === 'es') { badge.textContent = 'SPANISH'; }
  else if (type === 'en') { badge.textContent = 'ENGLISH'; }
  else if (type === 'claimed') {
    badge.textContent = 'SPANISH';
    claimBtn.className = 'tg-btn taken-btn';
    claimBtn.textContent = '✅ Sara claimed this';
    claimBtn.onclick = null;
    systemMsg.classList.add('visible');
  }
}

function tgClaim() {
  if (tgClaimed) return;
  tgClaimed = true;
  const claimBtn = document.getElementById('tg-claim-btn');
  claimBtn.className = 'tg-btn claimed-btn';
  claimBtn.textContent = '✅ You claimed this';
  claimBtn.onclick = null;
  document.getElementById('tg-claimed-msg').classList.add('visible');
  setTimeout(() => document.getElementById('tg-system-msg').classList.add('visible'), 500);
}

// ═══ Evie Chat ═══
const SYSTEM_PROMPT = `You are Evie, the Stay Blessed Insurance AI assistant. Your job is to help car dealership salespeople in Florida submit insurance for their customers quickly and confidently.

You are talking to a salesperson named Lee at Premier Auto Group.
Active submission: SB-2401, Maria Rodriguez, 2022 Honda CR-V, currently stage 3 (Quoting) with Sara.

HARD RULES — never break these:
- NEVER quote rates or price ranges. If asked: "I can't share rates — send the Bill of Sale and we'll have a real number back in minutes."
- NEVER name insurance carriers. Say "our markets" or "our carriers" only.
- NEVER bind, cancel, or modify a policy.
- NEVER share other dealers' data.
- NEVER give legal, tax, or financial advice.
- If unsure or edge case: "Let me get Benny on this — texting him now."

You CAN: answer coverage questions, handle objections, check submission status, explain missing fields, answer Florida insurance questions.

Keep responses short and confident — max 2-3 sentences on mobile.`;

let chatHistory = [];
let chatLoading = false;

async function callEvie(msg) {
  const messages = chatHistory.map(m => ({ role: m.role, content: m.content }));
  messages.push({ role: 'user', content: msg });
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: 'claude-sonnet-4-20250514', max_tokens: 1000, system: SYSTEM_PROMPT, messages })
  });
  const data = await res.json();
  return data.content?.[0]?.text || "Sorry, can't reach the server right now.";
}

function updateSendBtn() {
  document.getElementById('send-btn').classList.toggle('active', document.getElementById('chat-input').value.trim().length > 0);
}

function quickAsk(text) {
  document.getElementById('chat-input').value = text;
  updateSendBtn();
  sendMessage();
}

async function sendMessage() {
  if (chatLoading) return;
  const input = document.getElementById('chat-input');
  const text = input.value.trim();
  if (!text) return;
  input.value = ''; updateSendBtn();
  chatLoading = true;
  addMsg('user', text);
  showTyping();
  document.getElementById('evie-thinking').style.display = 'block';
  try {
    const reply = await callEvie(text);
    hideTyping();
    document.getElementById('evie-thinking').style.display = 'none';
    const isEscalation = reply.toLowerCase().includes('benny');
    addMsg('assistant', reply, isEscalation);
    chatHistory.push({ role: 'user', content: text });
    chatHistory.push({ role: 'assistant', content: reply });
  } catch(e) {
    hideTyping();
    document.getElementById('evie-thinking').style.display = 'none';
    addMsg('assistant', "Can't reach the server right now — try again in a moment.");
  }
  chatLoading = false;
}

function addMsg(role, text, escalated = false) {
  const container = document.getElementById('chat-messages');
  const row = document.createElement('div');
  row.className = 'msg-row ' + role;
  if (role === 'assistant' && escalated) {
    row.innerHTML = `<div class="msg-bubble assistant escalated"><div class="escalate-tag"><svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"/></svg> Escalating to Benny</div>${text}</div>`;
  } else {
    row.innerHTML = `<div class="msg-bubble ${role}">${text}</div>`;
  }
  container.appendChild(row);
  container.scrollTop = container.scrollHeight;
}

function showTyping() {
  const container = document.getElementById('chat-messages');
  const row = document.createElement('div');
  row.id = 'typing';
  row.className = 'msg-row assistant';
  row.innerHTML = '<div class="typing-bubble"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div>';
  container.appendChild(row);
  container.scrollTop = container.scrollHeight;
}
function hideTyping() { const t = document.getElementById('typing'); if (t) t.remove(); }

function openChat() {
  document.getElementById('chat-panel').classList.add('active');
  document.getElementById('ai-fab').style.display = 'none';
}
function closeChat() {
  document.getElementById('chat-panel').classList.remove('active');
  document.getElementById('ai-fab').style.display = 'flex';
}

// Init tracker
goToTracker(3);
showScreen('home');
